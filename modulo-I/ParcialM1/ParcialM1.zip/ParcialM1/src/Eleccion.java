public enum Eleccion {
    PIEDRA, PAPEL, TIJERA
}
